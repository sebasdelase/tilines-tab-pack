Tilines SMP TAB Logo HQ v2 - Minecraft Java 1.21.1
TAB line:
<font:tilines:logo>\uE101\uE102\uE103</font>
