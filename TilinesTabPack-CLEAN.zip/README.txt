Use <font:tilines:logo>\uE121</font>. Put ONE blank header line BEFORE logo. No blank lines after logo. Height 22 ascent 19.
