Tilines SMP TAB Logo - fixed for Minecraft Java 1.21.1

Use this character as the first TAB header line:
\uE001

Recommended YAML:
- "\uE001"

This pack also keeps the custom font id tilines:logo for compatibility.
