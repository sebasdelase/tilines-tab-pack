Tilines SMP TAB logo resource pack

What this pack does:
- Adds the Tilines SMP logo as a custom font glyph for Minecraft
- Lets TAB display the logo in the header using:
  <font:tilines:logo></font>

Install:
1. Upload TilinesTabPack.zip somewhere with a DIRECT download link.
2. Put that link in server.properties as resource-pack=
3. Add the TAB header line to your TAB config.
4. Reload TAB or restart the server.
