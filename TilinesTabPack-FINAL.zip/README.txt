Tilines SMP TAB Logo FINAL for Minecraft 1.21.1
TAB glyph: <font:tilines:logo>\uE101\uE102\uE103</font>
Render size: about 96x32 logical GUI pixels.
Ascent 7 keeps the logo inside the TAB panel.
Use 3 blank header lines immediately after the logo line.
