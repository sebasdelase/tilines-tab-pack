Tilines SMP FINALFIX
U+E001
256x86 source
height=18 ascent=7
