Tilines SMP TAB logo REALFIX
Single glyph U+E001
height=26 ascent=8
No seams. Designed to stay inside TAB with one blank line after the logo.
